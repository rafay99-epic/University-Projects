<?php require_once 'auth/sessman.php'; // remove this after testing is over ?>

<!DOCTYPE html>

<html lang="en">

<head></head>

<body>

<p>Welcome to home page</p>
<p><a href="auth/logout.php">Logout</a>


</body>

</html>
